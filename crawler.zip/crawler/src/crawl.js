const request = require('request-promise');
const cheerio = require('cheerio');
const fs = require('fs');
const _ = require('lodash');

const req_url = 'https://wiprodigital.com/';

const { MAX_PAGES, UNKNOWN_SERVICE, ERRORED, IMAGES, VISITED, EXTERNAL, NOT_REACHEBLE, ALREADY_VISITED } = require('./constants.json');

let data = { visited: [], external: [], errored: [], images: [] };

function getURL(url) {
    if (url[url.length - 1] === '/') {
        return url.slice(0, url.length - 1)
    }
    return url;
}

async function parsePage(inputUrl) {
    const url = getURL(inputUrl);
    if (data.visited.indexOf(url) === -1 && data.errored.indexOf(url) === -1 && data.visited.length < MAX_PAGES) {
        console.log('looking at :', url);
        let response = await request.get(url).catch((err) => {
            pushtoStorage(ERRORED, url);
            console.log('didn"t response for ', url, err.message);
        });
        if (response) {
            console.log('got response for', url);
            pushtoStorage(VISITED, url);
            const $ = cheerio.load(response);
            const images = Array.from($('img'));
            const imagesUrl = images.reduce((acc, image) => {
                const src = $(image).attr("src");
                if (src)
                    acc.push(src);
                return acc;
            }, []);
            pushtoStorage(IMAGES, imagesUrl);
            const allLinksElem = Array.from($('a'));
            const externalLinks = [];
            const internalLinks = [];
            allLinksElem.forEach((link) => {
                const linkUrl = $(link).attr('href');
                if (linkUrl) {
                    if (linkUrl.startsWith('/') || linkUrl.startsWith(req_url) || linkUrl.startsWith('#')) {
                        const finalUrl = linkUrl.startsWith('/') ? `${req_url}${linkUrl}` : linkUrl;
                        internalLinks.push(finalUrl);
                    }
                    else {
                        externalLinks.push(linkUrl);
                    }
                }
            });
            pushtoStorage(EXTERNAL, externalLinks);
            for (let i = 0; i < internalLinks.length; i++) {
                if (!internalLinks[i].startsWith('#')) {
                    await parsePage(internalLinks[i]).catch((err) => {
                        console.log(err);
                    });
                }
            }
            return Promise.resolve((true));
        };
        return Promise.reject({ code: NOT_REACHEBLE });
    }
    console.log('not looking at', inputUrl);
    return Promise.reject({ code: ALREADY_VISITED });
};

(async (url) => {
    await parsePage(url).catch((err) => { pushtoStorage(ERRORED, url); });
    fs.writeFile("./parsedData.json", JSON.stringify(data), function (err) {
        if (err) {
            return console.log(err);
        }
        console.log("The file was saved!");
    });
})(req_url);


function pushtoStorage(service, payload) {
    switch (service) {
        case 'visited':
            data.visited.push(payload);
            break;
        case 'errored':
            data.errored.push(payload);
            break;
        case 'images':
            data.images = _.union(data.images, payload);
            break;
        case 'external':
            data.external = _.union(data.external, payload);
            break;
        default:
            console.log(UNKNOWN_SERVICE);
    }
}




